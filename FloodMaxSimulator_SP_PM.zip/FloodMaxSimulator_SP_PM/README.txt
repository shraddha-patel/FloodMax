Distributed Computing Project: FloodMax Simulator (For Synchronous Systems)

Authors: Shraddha Patel <skp140230@utdallas.edu>
	 Priyanka Menghani <pxm143730@utdallas.edu>


Compilation Instructions:
The project is written in Java. In order to compile, one must
 use the javac application to compile Java source files into 
Java class files that are executable by the JVM.



We have used the cs1 system on campus.



The samlpe input file
(Input-File.txt) consists of 
(1)The number of processes (n)
(2)An array of length n for process-ids
(3)Symmetric matrix of size n*n
 for connetivity  
 

The Output-File.txt file demonstrates the output of the program
 running against the provided Input-File.txt file.
